<?php
/**
 * Plugin Name: Millionisho Licensing
 * Plugin URI: https://webmasterbartar.ir
 * Description: A licensing system for Millionisho Telegram Bot
 * Version: 1.0.0
 * Author: Millionisho
 * Author URI: https://webmasterbartar.ir
 * Text Domain: millionisho-licensing
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Register REST API endpoints
add_action('rest_api_init', function () {
    // Register verify endpoint
    register_rest_route('licensing/v1', '/verify', array(
        'methods' => 'GET',
        'callback' => 'millionisho_verify_license',
        'permission_callback' => '__return_true',
    ));

    // Register add license endpoint (protected by admin)
    register_rest_route('licensing/v1', '/add', array(
        'methods' => 'POST',
        'callback' => 'millionisho_add_license',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ));
});

/**
 * Verify a license key
 */
function millionisho_verify_license($request) {
    $key = $request->get_param('key');
    
    if (empty($key)) {
        return new WP_REST_Response(array(
            'status' => 'invalid',
            'message' => 'No license key provided'
        ), 400);
    }

    // Get licenses from options
    $licenses = get_option('millionisho_licenses', array());
    
    // Check if license exists and is valid
    if (isset($licenses[$key]) && $licenses[$key]['status'] === 'valid') {
        return array(
            'status' => 'valid',
            'message' => 'License is valid'
        );
    }

    return array(
        'status' => 'invalid',
        'message' => 'Invalid license key'
    );
}

/**
 * Add a new license key (admin only)
 */
function millionisho_add_license($request) {
    $key = $request->get_param('key');
    
    if (empty($key)) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => 'No license key provided'
        ), 400);
    }

    // Get existing licenses
    $licenses = get_option('millionisho_licenses', array());
    
    // Add new license
    $licenses[$key] = array(
        'status' => 'valid',
        'created_at' => current_time('mysql'),
    );

    // Update licenses in database
    update_option('millionisho_licenses', $licenses);

    return array(
        'status' => 'success',
        'message' => 'License added successfully'
    );
}

/**
 * Add admin menu
 */
add_action('admin_menu', function () {
    add_menu_page(
        'مدیریت لایسنس‌ها',
        'لایسنس‌های میلیونی‌شو',
        'manage_options',
        'millionisho-licenses',
        'millionisho_licenses_page',
        'dashicons-lock',
        30
    );
});

/**
 * Render admin page
 */
function millionisho_licenses_page() {
    // Handle form submission
    if (isset($_POST['add_license']) && check_admin_referer('millionisho_add_license')) {
        $key = sanitize_text_field($_POST['license_key']);
        $licenses = get_option('millionisho_licenses', array());
        $licenses[$key] = array(
            'status' => 'valid',
            'created_at' => current_time('mysql'),
        );
        update_option('millionisho_licenses', $licenses);
        echo '<div class="notice notice-success"><p>لایسنس با موفقیت اضافه شد.</p></div>';
    }

    // Get all licenses
    $licenses = get_option('millionisho_licenses', array());
    ?>
    <div class="wrap">
        <h1>مدیریت لایسنس‌های میلیونی‌شو</h1>
        
        <h2>افزودن لایسنس جدید</h2>
        <form method="post" action="">
            <?php wp_nonce_field('millionisho_add_license'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="license_key">کلید لایسنس</label></th>
                    <td>
                        <input type="text" id="license_key" name="license_key" class="regular-text" required>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="add_license" class="button button-primary" value="افزودن لایسنس">
            </p>
        </form>

        <h2>لایسنس‌های موجود</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>کلید لایسنس</th>
                    <th>وضعیت</th>
                    <th>تاریخ ایجاد</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($licenses as $key => $data): ?>
                <tr>
                    <td><?php echo esc_html($key); ?></td>
                    <td><?php echo $data['status'] === 'valid' ? 'معتبر' : 'نامعتبر'; ?></td>
                    <td><?php echo esc_html($data['created_at']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
} 